//$Id: ValidatePreInsertEventListener.java 11282 2007-03-14 22:05:59Z epbernard $
package org.hibernate.validator.event;

/**
 * Before insert, execute the validator framework
 *
 * @deprecated use ValidateEventListener
 * 
 * @author Gavin King
 */
public class ValidatePreInsertEventListener extends ValidateEventListener {

}
