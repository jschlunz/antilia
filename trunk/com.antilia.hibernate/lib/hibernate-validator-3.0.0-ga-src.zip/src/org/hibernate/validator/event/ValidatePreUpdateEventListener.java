//$Id: ValidatePreUpdateEventListener.java 11282 2007-03-14 22:05:59Z epbernard $
package org.hibernate.validator.event;

/**
 * Before update, execute the validator framework
 *
 * @deprecated use ValidateEventListener
 *
 * @author Gavin King
 */
public class ValidatePreUpdateEventListener extends ValidateEventListener {

}
